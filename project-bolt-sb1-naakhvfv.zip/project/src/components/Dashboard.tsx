import React, { useState } from 'react';
import { 
  Calendar, 
  FileText, 
  Users, 
  Settings, 
  Video, 
  Pill, 
  Clock,
  Plus,
  Bell,
  Search,
  Filter
} from 'lucide-react';

interface DashboardProps {
  user: {
    name: string;
    role: 'admin' | 'doctor' | 'patient' | 'pharmacist';
    email: string;
  };
}

export default function Dashboard({ user }: DashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const getMenuItems = () => {
    switch (user.role) {
      case 'patient':
        return [
          { id: 'overview', label: 'Overview', icon: Calendar },
          { id: 'appointments', label: 'Appointments', icon: Video },
          { id: 'records', label: 'Medical Records', icon: FileText },
          { id: 'prescriptions', label: 'Prescriptions', icon: Pill },
        ];
      case 'doctor':
        return [
          { id: 'overview', label: 'Overview', icon: Calendar },
          { id: 'consultations', label: 'Consultations', icon: Video },
          { id: 'patients', label: 'Patients', icon: Users },
          { id: 'prescriptions', label: 'Prescriptions', icon: Pill },
        ];
      case 'pharmacist':
        return [
          { id: 'overview', label: 'Overview', icon: Calendar },
          { id: 'prescriptions', label: 'Prescriptions', icon: Pill },
          { id: 'inventory', label: 'Inventory', icon: FileText },
          { id: 'orders', label: 'Orders', icon: Clock },
        ];
      case 'admin':
        return [
          { id: 'overview', label: 'Overview', icon: Calendar },
          { id: 'users', label: 'User Management', icon: Users },
          { id: 'system', label: 'System Settings', icon: Settings },
          { id: 'reports', label: 'Reports', icon: FileText },
        ];
      default:
        return [];
    }
  };

  const menuItems = getMenuItems();

  const renderOverview = () => {
    switch (user.role) {
      case 'patient':
        return (
          <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Next Appointment</p>
                    <p className="text-2xl font-bold text-gray-900">Today, 2:00 PM</p>
                    <p className="text-sm text-blue-600">Dr. Sarah Johnson</p>
                  </div>
                  <Video className="h-8 w-8 text-blue-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Prescriptions</p>
                    <p className="text-2xl font-bold text-gray-900">3</p>
                    <p className="text-sm text-green-600">2 ready for pickup</p>
                  </div>
                  <Pill className="h-8 w-8 text-green-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Health Score</p>
                    <p className="text-2xl font-bold text-gray-900">92%</p>
                    <p className="text-sm text-green-600">Excellent</p>
                  </div>
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <div className="w-4 h-4 bg-green-600 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">Upcoming Appointments</h3>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                    Book New
                  </button>
                </div>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {[
                    { doctor: 'Dr. Sarah Johnson', specialty: 'Cardiology', date: 'Today', time: '2:00 PM', type: 'Virtual' },
                    { doctor: 'Dr. Michael Chen', specialty: 'Dermatology', date: 'Tomorrow', time: '10:30 AM', type: 'Virtual' },
                    { doctor: 'Dr. Emily Davis', specialty: 'General Medicine', date: 'Thu, Dec 21', time: '3:15 PM', type: 'In-person' }
                  ].map((appointment, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{appointment.doctor}</p>
                          <p className="text-sm text-gray-600">{appointment.specialty}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900">{appointment.date}</p>
                        <p className="text-sm text-gray-600">{appointment.time}</p>
                        <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                          appointment.type === 'Virtual' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                          {appointment.type}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 'doctor':
        return (
          <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Today's Consultations</p>
                    <p className="text-2xl font-bold text-gray-900">8</p>
                  </div>
                  <Video className="h-8 w-8 text-blue-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Patients</p>
                    <p className="text-2xl font-bold text-gray-900">247</p>
                  </div>
                  <Users className="h-8 w-8 text-green-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Prescriptions Written</p>
                    <p className="text-2xl font-bold text-gray-900">156</p>
                  </div>
                  <Pill className="h-8 w-8 text-purple-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Rating</p>
                    <p className="text-2xl font-bold text-gray-900">4.9</p>
                  </div>
                  <div className="text-yellow-500 text-xl">⭐</div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">Today's Schedule</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-3">
                    {[
                      { time: '9:00 AM', patient: 'John Doe', type: 'Follow-up' },
                      { time: '10:30 AM', patient: 'Jane Smith', type: 'Initial Consultation' },
                      { time: '2:00 PM', patient: 'Mike Johnson', type: 'Prescription Review' },
                      { time: '3:30 PM', patient: 'Sarah Wilson', type: 'Lab Results' }
                    ].map((appointment, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{appointment.time}</p>
                          <p className="text-sm text-gray-600">{appointment.patient}</p>
                        </div>
                        <span className="px-2 py-1 bg-blue-100 text-blue-600 text-xs rounded-full">
                          {appointment.type}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    {[
                      { action: 'Consultation completed', patient: 'John Doe', time: '30 minutes ago' },
                      { action: 'Prescription sent', patient: 'Jane Smith', time: '1 hour ago' },
                      { action: 'Lab results reviewed', patient: 'Mike Johnson', time: '2 hours ago' },
                      { action: 'Appointment scheduled', patient: 'Sarah Wilson', time: '3 hours ago' }
                    ].map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                          <p className="text-xs text-gray-600">{activity.patient} • {activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'pharmacist':
        return (
          <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Pending Orders</p>
                    <p className="text-2xl font-bold text-gray-900">24</p>
                  </div>
                  <Clock className="h-8 w-8 text-orange-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Ready for Pickup</p>
                    <p className="text-2xl font-bold text-gray-900">12</p>
                  </div>
                  <Pill className="h-8 w-8 text-green-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Low Stock Items</p>
                    <p className="text-2xl font-bold text-gray-900">7</p>
                  </div>
                  <FileText className="h-8 w-8 text-red-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Today's Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">$2,340</p>
                  </div>
                  <div className="text-green-600">💰</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Recent Prescription Orders</h3>
              </div>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-sm font-medium text-gray-500">
                        <th className="pb-3">Patient</th>
                        <th className="pb-3">Medication</th>
                        <th className="pb-3">Doctor</th>
                        <th className="pb-3">Status</th>
                        <th className="pb-3">Time</th>
                      </tr>
                    </thead>
                    <tbody className="space-y-2">
                      {[
                        { patient: 'John Doe', medication: 'Lisinopril 10mg', doctor: 'Dr. Smith', status: 'Pending', time: '30 min ago' },
                        { patient: 'Jane Wilson', medication: 'Metformin 500mg', doctor: 'Dr. Johnson', status: 'Ready', time: '1 hour ago' },
                        { patient: 'Mike Brown', medication: 'Atorvastatin 20mg', doctor: 'Dr. Davis', status: 'Dispensed', time: '2 hours ago' }
                      ].map((order, index) => (
                        <tr key={index} className="border-t">
                          <td className="py-3 font-medium text-gray-900">{order.patient}</td>
                          <td className="py-3 text-gray-600">{order.medication}</td>
                          <td className="py-3 text-gray-600">{order.doctor}</td>
                          <td className="py-3">
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              order.status === 'Pending' ? 'bg-yellow-100 text-yellow-600' :
                              order.status === 'Ready' ? 'bg-green-100 text-green-600' :
                              'bg-blue-100 text-blue-600'
                            }`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="py-3 text-gray-600">{order.time}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        );

      case 'admin':
        return (
          <div className="space-y-6">
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Users</p>
                    <p className="text-2xl font-bold text-gray-900">1,247</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Consultations</p>
                    <p className="text-2xl font-bold text-gray-900">89</p>
                  </div>
                  <Video className="h-8 w-8 text-green-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">System Uptime</p>
                    <p className="text-2xl font-bold text-gray-900">99.9%</p>
                  </div>
                  <Settings className="h-8 w-8 text-purple-600" />
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Revenue</p>
                    <p className="text-2xl font-bold text-gray-900">$45.2K</p>
                  </div>
                  <div className="text-green-600">📈</div>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">User Registration Trends</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Patients</span>
                      <span className="font-semibold">847 (+12%)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Doctors</span>
                      <span className="font-semibold">89 (+5%)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Pharmacists</span>
                      <span className="font-semibold">34 (+2%)</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">System Alerts</h3>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Bell className="h-5 w-5 text-yellow-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Server maintenance scheduled</p>
                        <p className="text-xs text-gray-600">Tonight 2:00 AM - 4:00 AM</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Bell className="h-5 w-5 text-red-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">High CPU usage detected</p>
                        <p className="text-xs text-gray-600">Server cluster #3</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Bell className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">Backup completed successfully</p>
                        <p className="text-xs text-gray-600">Daily backup - All systems</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return <div>Dashboard content</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r border-gray-200">
          <div className="p-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">{user.name}</p>
                <p className="text-sm text-gray-500 capitalize">{user.role}</p>
              </div>
            </div>
          </div>

          <nav className="px-4 pb-4">
            <ul className="space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === item.id
                          ? 'bg-blue-50 text-blue-600 border-blue-200'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <div className="p-8">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Welcome back, {user.name.split(' ')[0]}!
              </h1>
              <p className="text-gray-600">
                Here's what's happening with your {user.role === 'admin' ? 'platform' : 'healthcare'} today.
              </p>
            </div>

            {renderOverview()}
          </div>
        </div>
      </div>
    </div>
  );
}