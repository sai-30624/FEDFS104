import React from 'react';
import { Video, FileText, Pill, Clock, Shield, Users } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Video,
      title: 'Virtual Consultations',
      description: 'Connect with doctors through secure video calls from anywhere.',
      features: ['HD Video Quality', 'Screen Sharing', 'Chat Support', 'Recording Available']
    },
    {
      icon: FileText,
      title: 'Medical Records',
      description: 'Access and manage your complete medical history securely.',
      features: ['Digital Storage', 'Easy Sharing', 'Lab Results', 'Prescription History']
    },
    {
      icon: Pill,
      title: 'E-Prescriptions',
      description: 'Get prescriptions sent directly to your preferred pharmacy.',
      features: ['Digital Prescriptions', 'Pharmacy Integration', 'Refill Reminders', 'Insurance Support']
    },
    {
      icon: Clock,
      title: '24/7 Availability',
      description: 'Healthcare services available whenever you need them.',
      features: ['Round-the-clock Care', 'Emergency Support', 'Weekend Availability', 'Holiday Coverage']
    },
    {
      icon: Shield,
      title: 'HIPAA Compliant',
      description: 'Your medical information is protected with enterprise-grade security.',
      features: ['End-to-end Encryption', 'Secure Data Storage', 'Privacy Protection', 'Compliance Certified']
    },
    {
      icon: Users,
      title: 'Specialist Network',
      description: 'Connect with a wide network of certified medical professionals.',
      features: ['Board-certified Doctors', 'Multiple Specialties', 'Verified Credentials', 'Patient Reviews']
    }
  ];

  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Comprehensive Healthcare Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need for modern healthcare delivery, from virtual consultations 
            to prescription management, all in one secure platform.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <div className="bg-white w-16 h-16 rounded-xl flex items-center justify-center mb-6 shadow-sm">
                  <Icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Ready to Transform Your Healthcare Experience?
            </h3>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Join thousands of patients and healthcare providers who trust MedConnect 
              for secure, convenient, and professional medical care.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                Get Started Today
              </button>
              <button className="border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-600 hover:text-white transition-colors">
                Schedule a Demo
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}