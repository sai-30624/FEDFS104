import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Footer from './components/Footer';
import LoginModal from './components/LoginModal';
import Dashboard from './components/Dashboard';

interface User {
  name: string;
  email: string;
  role: 'admin' | 'doctor' | 'patient' | 'pharmacist';
}

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsLoginModalOpen(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleGetStarted = () => {
    if (currentUser) {
      // User is already logged in, could redirect to booking or dashboard
      return;
    }
    setIsLoginModalOpen(true);
  };

  // If user is logged in, show their dashboard
  if (currentUser) {
    return <Dashboard user={currentUser} />;
  }

  // Otherwise, show the landing page
  return (
    <div className="min-h-screen bg-white">
      <Header 
        currentUser={currentUser} 
        onLogin={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
      />
      <Hero onGetStarted={handleGetStarted} />
      <Services />
      <Footer />
      
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}

export default App;